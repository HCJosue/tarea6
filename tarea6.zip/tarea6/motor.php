<?php
session_start();
include "conexion.php";
$flujo=$_GET["flujo"];
$ticket=$_GET["ticket"];
$proceso=$_GET["proceso"];
$pantalla=$_GET["pantalla"];
$ci=$_GET["ci"];
$pagado=-1;
include "seguimiento.php";
include "guardar/".$pantalla.".php";
if (isset($_GET["atras"]))
{
	$sql="select * from procesos where flujo='".$flujo."' 
	and procesosiguiente='".$proceso."' ";	
	$resultado=mysqli_query($con, $sql);
	$registro=mysqli_fetch_array($resultado);
	$procesosiguiente=$registro["procesoactual"];
	if($procesosiguiente==""){
		$buscacondicional=mysqli_query($con,"select * from condicional where POSITIVO like '".$proceso."' or NEGATIVO like '".$proceso."'");
		$sacardato=mysqli_fetch_array($buscacondicional);
		$procesosiguiente=$sacardato["proceso"];
	}
}

if (isset($_GET["adelante"]))
{
	$sql="select * from procesos where flujo like '".$flujo."' 
	and procesoactual like '".$proceso."'";	
	$resultado=mysqli_query($con, $sql);
	$registro=mysqli_fetch_array($resultado);
	$procesosiguiente=$registro["procesosiguiente"];
	if($procesosiguiente==""){
		$buscacondicional=mysqli_query($con,"select * from condicional where proceso like '".$proceso."'");
		$sacardato=mysqli_fetch_array($buscacondicional);
		if($pagado==1){
			$procesosiguiente=$sacardato["POSITIVO"];
		}
		else{
			$procesosiguiente=$sacardato["NEGATIVO"];
		}
	}
	if($valor==0){
		$fecha=date('Y-m-d h:i:s');
		$sql3="update seguimiento set fechafin='".$fecha."' where ticket=".$ticket." and flujo='".$flujo."' and proceso='".$proceso."'";
		mysqli_query($con,$sql3);
		$sql3="insert into seguimiento values($ticket,'$flujo','$procesosiguiente','$fecha',NULL,$ci)";
		mysqli_query($con,$sql3);
	}
}
//proceso otros
//retornar al flujo siguiente-anterior
header("Location: principal.php?ticket=".$ticket."&flujo=".$flujo."&procesoactual=".$procesosiguiente);
?>