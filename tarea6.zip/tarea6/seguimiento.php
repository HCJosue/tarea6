<?php
    $sql2="select * from seguimiento where ticket=".$ticket." and flujo like '".$flujo."' and proceso like '".$proceso."'";
	$resultado2=mysqli_query($con,$sql2);
	$registro2=mysqli_fetch_array($resultado2);
	if(isset($registro2["fechafin"])){
       $valor=1;
    }
    else{
        $valor=0;
    }
?>