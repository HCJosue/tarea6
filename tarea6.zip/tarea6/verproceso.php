<?php
    session_start();
    include("conexion.php");
    $ticket=$_GET["ticket"];
    $resultado2=mysqli_query($con,"select * from academico.persona where ci=".$_SESSION["ci"]);
    $fila2=mysqli_fetch_array($resultado2);
    $resultado=mysqli_query($con,"select count(*) nro from seguimiento where usuario=".$_SESSION["ci"]);
    $fila=mysqli_fetch_array($resultado);
    include("cabecera.php");
?>
  <div class="container bg-primary mt-2 rounded shadow text-light py-2">
  <h2 class="text-center display-4">Proceso en espera</h2>
  <table class="table border border-light text-light">
  <thead>
    <tr class="thead-light">
      <th scope="col">Ticket</th>
      <th scope="col">Flujo</th>
      <th scope="col">Proceso</th>
      <th scope="col">Fecha inicio</th>
      <th scope="col">Completar operacion</th>
    </tr>
  </thead>
  <tbody>
    <?php
      $r='<i class="fa-solid fa-calendar-check fa-2xl" style="color: #ffffff;"></i>';
      $resultado=mysqli_query($con,"select *  from seguimiento where ticket=".$ticket." and fechafin is null");
      while($fila=mysqli_fetch_array($resultado)){
        echo "<tr><td>".$fila['ticket']."</td>";
        echo "<td>".$fila['flujo']."</td>";
        echo "<td>".$fila['proceso']."</td>";
        echo "<td>".$fila['fechaini']."</td>";
        echo "<td><a href='principal.php?ticket=".$fila['ticket']."&flujo=".$fila['flujo']."&procesoactual=".$fila['proceso']."'>$r</a></td></tr>";
      }
    ?>
</tbody>
</table> 
    <h2 class="text-center display-4">Procesos acabado</h2>
    <table class="table text-light border border-light py-2">
  <thead>
    <tr class="thead-light">
      <th scope="col">Ticket</th>
      <th scope="col">Flujo</th>
      <th scope="col">Proceso</th>
      <th scope="col">Fecha inicio</th>
      <th scope="col">Fecha fin</th>
      <th scope="col">Resultado</th>
    </tr>
  </thead>
  <tbody>
  <?php
      $r='<i class="fa-solid fa-circle-check fa-xl" style="color: #63E6BE;"></i>';
      $resultado=mysqli_query($con,"select *  from seguimiento where ticket=".$ticket." and fechafin is not null");
      while($fila=mysqli_fetch_array($resultado)){
        echo "<tr><td>".$fila['ticket']."</td>";
        echo "<td>".$fila['flujo']."</td>";
        echo "<td>".$fila['proceso']."</td>";
        echo "<td>".$fila['fechaini']."</td>";
        echo "<td>".$fila["fechafin"]."</td><td>$r</td></tr>";
      }
    ?>
</tbody>
</table> 
  </div>
<?php
    include("pie.php");
?>