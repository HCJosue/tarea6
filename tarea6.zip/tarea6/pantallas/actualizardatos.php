<?php
    echo "<h2>Proceso 2: Actualizar datos</h2><br>";
    $sacardatos=mysqli_query($con,"select * from academico.persona where CI=".$_SESSION["ci"]);
    $datos=mysqli_fetch_array($sacardatos);
    include "seguimiento.php";
    if($valor==0){
?>
 <div class="form-group">
    <label for="exampleInputEmail1">Nombre</label>
    <input type="text" class="form-control" id="nombre" name="nombre" 
     placeholder="<?php echo $datos["nombre"];?>"/>
</div>
<div class="form-group">
    <label for="exampleInputEmail1">Apellido</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="apellido"
     placeholder="<?php echo $datos["apellido"];?>">
</div>
<?php }
    else{
        echo "<h4 class='hecho'>Usted ya actualizo su nombre a ".$datos['nombre']." ".$datos['apellido']."</h4>";
    }  
?>
    
