<?php
    include "seguimiento.php";
    echo "<h2>Proceso 7: Imprime tu matricula</h2><br>";
    if($_SESSION["rol"]=="estudiante"){
?>
<h4 class='hecho'>Click para ver su matricula <a href="matricula.php"><i class="fa-solid fa-file-arrow-down fa-2xl" style="color: #00ffb3;"></i></a></h4>
<?php
    }
    else{
?>
<h4 class='hecho'>Tu trabajo ya termino, ve a la bandeja de salida para revisar otros procesos</h4>
<?php
    }
?>