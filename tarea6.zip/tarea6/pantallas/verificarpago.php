<?php
    include "seguimiento.php";
    $ci=$registro2['usuario'];
    $sql="select * from academico.persona a,academico.pagos xp where a.ci=".$ci." and xp.ci=".$ci." and cpt=".$ticket;
    $buscardatos=mysqli_query($con,$sql);
    $sacardatos=mysqli_fetch_array($buscardatos);
    echo "<h2>Proceso 5: Verificar pago</h2><br>";
    if("estudiante"==$_SESSION["rol"]){
        if($valor==0){
            echo "<h4>El boton de 'completar proceso' se mostrara cuando kardex apreuba las actualizaciones</h4>";
        }
        else{
            echo "<h4 class='hecho'>Kardex ya verifico su pago, presione 'completar proceso' para ver su respuesta</h4>";
        }
    }
    else{
        if($valor==0){
        echo "<h4>Verificar en la tabla de pagos si el estudiante ".$sacardatos["nombre"]." ".$sacardatos["apellido"]." con codigo CPT ".$sacardatos["cpt"]." realizo su pago</h4>";
?>
    <div class="form-check">
        <div>
            <input type="radio" id="huey" name="revisar" value="si" checked />
            <label for="huey">SI</label>
        </div>

        <div>
            <input type="radio" id="dewey" name="revisar" value="no" />
            <label for="dewey">NO</label>
        </div>
    </div>
<?php
        }
    else{
        $datossi=mysqli_query($con,"select * from seguimiento where ticket=".$ticket." order by proceso DESC");
            $mensaje="no";
            while($sacarsi=mysqli_fetch_array($datossi)){
                if($sacarsi["proceso"]=="P6"){
                    $mensaje="si";
                }
            }
        echo "<h4 class='hecho'>Usted coloco ".$mensaje." al verificar del codigo CPT ".$sacardatos['cpt']."</h4>";
    }
    }
?>