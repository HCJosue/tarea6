<?php
    include "conexion.php";
    include "seguimiento.php";
    echo "<h2>Proceso 8: Error en el pago</h2>";
    if($_SESSION["rol"]=="estudiante"){
        $sacarcuenta=mysqli_query($con,"select * from academico.pagos where ci=".$_SESSION["ci"]);
        $sacardatos=mysqli_fetch_array($sacarcuenta);
        echo "<h3 id='error'>Hubo un error en el pago de matricula por falta de fondo en la cuenta ".$sacardatos["cuenta"]."</h3>";
    }
    else{
        echo "<h4>Aqui acabo tu trabajo, vuelve en la bandeja de salida para revisar otros casos</h4>";
    }
?>