<?php
    echo "<h2>Proceso 9: No habilitado</h2>";
    if($_SESSION["rol"]=="estudiante"){
        echo "<h4 id='error'>Usted no esta habilitado para obtener matricula</h4>";
    }
    else{
        echo "<h4 class='hecho'>Aqui acabo tu trabajo, vuelve en la bandeja de salida para revisar otros casos</h4>";
    }
?>