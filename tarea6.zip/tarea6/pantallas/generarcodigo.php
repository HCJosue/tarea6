<?php
    include "seguimiento.php";
    if($valor==0){
        $cpt=mysqli_query($con,"select max(cpt) max from academico.pagos");
        $max=mysqli_fetch_array($cpt);
        if(!isset($max["max"])){
            $codigocpt=1;
        }
        else{
            $codigocpt=$max["max"]+1;
        }
        echo "<h2>Proceso 3: Generar codigo CPT</h2><br>";
?>
<h4>Tu codigo CPT es <?php  echo $codigocpt;?></h4>
<input type="hidden" value="<?php echo $codigocpt;?>" name="codigocpt"/>
<?php }
else{
    $cpt=mysqli_query($con,"select * from academico.pagos where ci=".$_SESSION['ci']);
    $max=mysqli_fetch_array($cpt);  
    echo "<h2>Proceso 3: Generar codigo CPT</h2><br>";
    echo "<h4 class='hecho'>Tu codigo CPT es: ".$max["cpt"]."</h4>";
}?>