<?php
    session_start();
    if($valor==0 && isset($_GET["adelante"])){
        $codigocpt=$_GET["codigocpt"];
        mysqli_query($con,"insert into academico.pagos values(".$codigocpt.",".$_SESSION["ci"].",0,-1)");
    }
?>