<?php
    session_start();
    include "conexion.php";
    $nombre=mysqli_query($con,"select * from academico.persona where ci=".$_SESSION["ci"]);
    $sacarnombre=mysqli_fetch_array($nombre);
    require("fpdf/fpdf.php");
    $pdf=new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(40,10,'Tu matricula: '.$sacarnombre["nombre"]." ".$sacarnombre["apellido"]);
    $pdf->Output();
?>
