<?php
    include("conexion.php");
    $usuario=$_POST['usuario'];
    $pass=$_POST['pass'];
    $pass=md5($pass);
    $resultado=mysqli_query($con,"select * from academico.usuario where usuario='".$usuario."' and password='".$pass."'");
    $fila=mysqli_fetch_array($resultado);
    if(empty($fila)){
        header("Location: index.php?error=si");
    }
    else{
        session_start();
        $_SESSION["ci"]=$fila['CI'];
        $_SESSION["rol"]=$fila['rol'];
        if($fila['rol']=="estudiante"){
            header("Location: estudiante.php");
        }
        if($fila['rol']=="kardex"){
            header("Location: kardex.php");
        }
    }
?>