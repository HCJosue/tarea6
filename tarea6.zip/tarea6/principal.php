<?php
    session_start();
    include "conexion.php";
    $resultado2=mysqli_query($con,"select * from academico.persona where ci=".$_SESSION["ci"]);
    $fila2=mysqli_fetch_array($resultado2);
    include "cabecera.php";
    $ticket=$_GET["ticket"];
    $procesoactual=$_GET["procesoactual"];
    $proceso=$procesoactual;
    $flujo=$_GET["flujo"];
    $resultado=mysqli_query($con,"select * from procesos where flujo='".$flujo."' and procesoactual='".$procesoactual."'");
    $fila=mysqli_fetch_array($resultado);
    $pantalla=$fila["pantalla"];
    if($_SESSION["rol"]=="estudiante"){
?>
    <div class="container p-2 py-2">
        <div class="row align-items-start">
            <div class="col-3">
            </div>
            <div class="col-6 bg-primary rounded text-center text-light">
                <form action="motor.php" method="GET">
                    <input type="hidden" value="<?php echo $pantalla;?>" name="pantalla"/>
                    <input type="hidden" value="<?php echo $flujo;?>" name="flujo"/>
                    <input type="hidden" value="<?php echo $procesoactual;?>" name="proceso"/>
                    <input type="hidden" value="<?php echo $ticket;?>" name="ticket"/>
                    <input type="hidden" value="<?php echo $_SESSION["ci"];?>" name="ci"/>
                    <?php include "pantallas/".$pantalla.".php";?>
                    <hr class="sidebar-divider">
                    <div class="row py-2">
                        <div class="col-auto mr-auto">
                        <?php
                            if ($procesoactual!="P1")
                            echo '<input type="submit" class="btn btn-light text-primary" name="atras" value="Anterior proceso"/>';
                        ?>
                        </div>
                        <div class="col-auto">
                        </div>
                        <div class="col-auto">
                        <?php
                            if(($_SESSION['rol']==$fila["usuario"] || $valor!=0) && $procesoactual!="P7" && $procesoactual!="P8"){
                                echo '<input type="submit" class="btn btn-light text-primary" name="adelante" value="Completar proceso"/>';
                            }
                        ?>
                        </div>   
                    </div>

                </form>
            </div>
            <div class="col-3">
                
            </div>
        </div>
    </div>
<?php
    }
    else{ ?>
    <div class="container p-2 py-2">
        <div class="row align-items-start">
            <div class="col bg-dark rounded text-white text-center">
                <form action="motor.php" method="GET">
                    <input type="hidden" value="<?php echo $pantalla;?>" name="pantalla"/>
                    <input type="hidden" value="<?php echo $flujo;?>" name="flujo"/>
                    <input type="hidden" value="<?php echo $procesoactual;?>" name="proceso"/>
                    <input type="hidden" value="<?php echo $ticket;?>" name="ticket"/>
                    <?php include "pantallas/".$pantalla.".php";?>
                    <input type="hidden" value="<?php echo $ci;?>" name="ci"/>
                    <hr class="sidebar-divider">
                    <div class="form-group">
                    <?php
                        if ($procesoactual!="P5")
                        echo '<input type="submit" class="btn btn-light text-dark" name="atras" value="Anterior proceso"/>';
                    ?>
                    <?php
                        if($_SESSION['rol']==$fila["usuario"]){
                            echo '<input type="submit" class="btn btn-light text-dark" name="adelante" value="Completar proceso"/>';
                        }
                    ?>
                    </div>
                </form>
            </div>
            <?php
                if($valor==0 && ($procesoactual!="P8" && $procesoactual!="P9")){
            ?>
            <div class="col bg-dark rounded text-white">
                <?php 
                    if($procesoactual=="P5"){
                ?>
                <h3>LISTA DE PAGOS</h3>
                <div class="form-group">
                <i class="fa-solid fa-money-bill fa-2xl" style="color: #04ff00;"> Pagado</i>
                <i class="fa-solid fa-money-bill fa-2xl" style="color: #ff0000;"> No pagado</i>
                </div>
                <table class="table text-light border border-white">
                    <thead>
                        <tr class="thead-light text-dark">
                            <th>Numero CPT</th>
                            <th>Pagado?</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php
                                $bien='<i class="fa-solid fa-money-bill fa-2xl" style="color: #04ff00;"></i>';
                                $mal='<i class="fa-solid fa-money-bill fa-2xl" style="color: #ff0000;"></i>';
                                $pago=mysqli_query($con,"select * from academico.pagos");
                                while($pagosh=mysqli_fetch_array($pago)){
                                    echo "<tr>";
                                    echo "<td>".$pagosh['cpt']."</td>";
                                    if($pagosh["pagado"]==1){
                                        echo "<td>$bien</td>";
                                    }
                                    else{
                                        echo "<td>$mal</td>";
                                    }
                                    echo "</tr>";
                                }
                            ?>
                    </tbody>
                </table>
                <?php }
                    if($proceso=="P6"){
                        ?>
                        <h3 class='text-center'>LISTA DE HABILITADOS</h3>
                        <div class="form-group">
                        <i class="fa-solid fa-user-check fa-xl" style="color: #8cff00;">Habilitado</i>
                        <i class="fa-solid fa-user-check fa-xl" style="color: #ff0000;">No habilitado</i>
                        </div>
                        <table class="table border border-light text-white">
                        <thead>
                            <tr class="thead-light">
                                <th>Nombre</th>
                                <th>Habilitado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $bien='<i class="fa-solid fa-user-check fa-2xl" style="color: #8cff00;"></i>';
                                $mal='<i class="fa-solid fa-user-check fa-2xl" style="color: #ff0000;"></i>';
                                $habilitados=mysqli_query($con,"select * from academico.persona xp, academico.habilitado xh where xh.nroci=xp.ci");
                                while($sacarhab=mysqli_fetch_array($habilitados)){
                                    echo "<tr>";
                                    echo "<td>".$sacarhab['nombre']." ".$sacarhab["apellido"]."</td>";
                                    if($sacarhab["puede"]==1){
                                        echo "<td>$bien</td>";
                                    }
                                    else{
                                        echo "<td>$mal</td>";
                                    }
                                    echo "</tr>";
                                }
                            ?>  
                        </tbody>
                        </table>
                    <?php
                    }
                ?>
            </div>
            <?php
                }
            ?>
        </div>
    </div>
<?php    }
    include "pie.php";
?>