<?php
    session_start();
    include("conexion.php");
    $resultado2=mysqli_query($con,"select * from academico.persona where ci=".$_SESSION["ci"]);
    $fila2=mysqli_fetch_array($resultado2);
    $resultado=mysqli_query($con,"select count(*) nro from seguimiento where usuario=".$_SESSION["ci"]);
    $fila=mysqli_fetch_array($resultado);
    include("cabecera.php");
?>
  <div class="container mt-2 rounded shadow text-light">
    <div class="row py-2">
      <div class="col-2"></div>
      <div class="col-8">
        <h2 class="text-center text-primary font-weight-bold">LISTA DE PROCESO</h2>
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen1.png" alt="First slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">INICIO</h4>
                <p class="text-white font-weight-bold">Iniciamos el proceso</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen2.jpg" alt="Second slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">ACTUALIZAR</h4>
                <p class="text-white font-weight-bold">Actualizamos nuestros datos</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen3.jpg" alt="Third slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">CODIGO CPT</h4>
                <p class="text-white font-weight-bold">Generamos nuestro codigo cpt</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen4.png" alt="Third slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">PAGAR</h4>
                <p class="text-white font-weight-bold">Pagamos con una cuenta</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen5.jpg" alt="Third slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">VERIFICAR</h4>
                <p class="text-white font-weight-bold">Kardex verifica nuestro pago</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen6.png" alt="Third slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">HABILITADO</h4>
                <p class="text-white font-weight-bold">Kardex verifica si estamos habilitados</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen7.png" alt="Third slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">IMPRIMIR</h4>
                <p class="text-white font-weight-bold">Podemos imprimir nuestra matricula</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen8.jpg" alt="Third slide">
              <div class="carousel-caption d-none d-md-block bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">ERROR DE PAGO</h4>
                <p class="text-white font-weight-bold">Kardex nos notifica error de pago</p>
              </div>
            </div>
            <div class="carousel-item">
              <img class="mh-100 w-100" style="height:400px" src="carusel/imagen9.png" alt="Third slide">
              <div class="carousel-caption d-none d-md-block  bg-gradient-primary rounded">
                <h4 class="text-white font-weight-bold">NO HABILITADO</h4>
                <p class="text-white font-weight-bold">Kardex nos notifica que nos estamos habilitados</p>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <i class="fa-solid fa-backward fa-2xl"></i>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <<i class="fa-solid fa-forward fa-2xl"></i>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
      <div class="col-2"></div>
    </div>
  </div>
<?php
    include("pie.php");
?>